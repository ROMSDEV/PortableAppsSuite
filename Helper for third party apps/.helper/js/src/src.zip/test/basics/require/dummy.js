module.exports = 'require/dummy';

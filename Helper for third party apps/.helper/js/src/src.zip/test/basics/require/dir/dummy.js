module.exports = 'dir/dummy';

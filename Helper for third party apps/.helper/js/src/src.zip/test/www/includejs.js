function getTitle () {
  return document.title;
}
